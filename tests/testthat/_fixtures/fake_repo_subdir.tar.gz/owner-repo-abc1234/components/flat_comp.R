#' @type derivation
#' @depends AVAL
#' @outputs NEWVAR
NEWVAR <- AVAL + 1
